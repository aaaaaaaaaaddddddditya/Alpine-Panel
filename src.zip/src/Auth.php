<?php
class Auth {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    public function login($email, $password) {
        $stmt = $this->pdo->prepare('SELECT id, email, password, role FROM users WHERE email = ? AND active = 1');
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user'] = $user;
            return true;
        }
        return false;
    }
    
    public function logout() {
        unset($_SESSION['user']);
        session_destroy();
    }
    
    public function isLoggedIn() {
        return isset($_SESSION['user']);
    }
    
    public function isAdmin() {
        return $this->isLoggedIn() && in_array($_SESSION['user']['role'], ['admin', 'owner']);
    }
    
    public function isOwner() {
        return $this->isLoggedIn() && $_SESSION['user']['role'] === 'owner';
    }
}
