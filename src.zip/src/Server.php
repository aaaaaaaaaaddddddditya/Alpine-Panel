<?php
class Server {
    private $pdo;
    private $auth;
    
    public function __construct($pdo, $auth) {
        $this->pdo = $pdo;
        $this->auth = $auth;
    }
    
    public function getServers() {
        if ($this->auth->isAdmin()) {
            $stmt = $this->pdo->query('SELECT * FROM servers ORDER BY created_at DESC');
        } else {
            $user = $_SESSION['user'];
            $stmt = $this->pdo->prepare('SELECT * FROM servers WHERE user_id = ? ORDER BY created_at DESC');
            $stmt->execute([$user['id']]);
        }
        return $stmt->fetchAll();
    }
    
    public function createServer($name, $version = '1.20.1', $ram = 1024) {
        $user = $_SESSION['user'];
        $docker_id = 'minecraft-' . uniqid();
        
        $stmt = $this->pdo->prepare('
            INSERT INTO servers (user_id, name, version, ram, docker_id, status, created_at)
            VALUES (?, ?, ?, ?, ?, ?, NOW())
        ');
        
        return $stmt->execute([
            $user['id'], $name, $version, $ram, $docker_id, 'offline'
        ]);
    }
    
    public function deleteServer($id) {
        $stmt = $this->pdo->prepare('DELETE FROM servers WHERE id = ?');
        return $stmt->execute([$id]);
    }
}
