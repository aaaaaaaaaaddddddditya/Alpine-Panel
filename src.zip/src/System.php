<?php
class System {
    public function getStats() {
        return [
            'cpu' => $this->getCpuUsage(),
            'memory' => $this->getMemoryUsage(),
            'disk' => $this->getDiskUsage(),
            'uptime' => $this->getUptime()
        ];
    }
    
    public function getCpuUsage() {
        return 0;
    }
    
    public function getMemoryUsage() {
        if (!file_exists('/proc/meminfo')) return ['percent' => 0];
        
        $meminfo = file_get_contents('/proc/meminfo');
        preg_match('/MemTotal:\s+(\d+)/', $meminfo, $total);
        preg_match('/MemAvailable:\s+(\d+)/', $meminfo, $available);
        
        $total_kb = $total[1] ?? 1;
        $available_kb = $available[1] ?? $total_kb;
        $used_kb = $total_kb - $available_kb;
        
        return ['percent' => round(($used_kb / $total_kb) * 100, 1)];
    }
    
    public function getDiskUsage() {
        $total = disk_total_space('/');
        $free = disk_free_space('/');
        $used = $total - $free;
        return ['percent' => round(($used / $total) * 100, 1)];
    }
    
    public function getUptime() {
        if (!file_exists('/proc/uptime')) return 'N/A';
        $uptime = file_get_contents('/proc/uptime');
        $uptime = explode(' ', $uptime);
        $seconds = (int)$uptime[0];
        $days = floor($seconds / 86400);
        return $days . ' days';
    }
}
