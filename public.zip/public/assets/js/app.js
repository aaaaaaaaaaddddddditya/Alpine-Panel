console.log('Alpine Panel loaded');

function refreshStats() {
    // Stats auto-refresh logic
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        refreshStats();
        setInterval(refreshStats, 5000);
    });
}
