<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
session_start();

require_once '../src/Auth.php';
require_once '../src/Server.php';
require_once '../src/System.php';
require_once '../config/database.php';
require_once '../config/app.php';

$auth = new Auth($pdo);
$server = new Server($pdo, $auth);
$system = new System();

$page = $_GET['page'] ?? 'dashboard';

// Handle logout
if (isset($_GET['logout'])) {
    $auth->logout();
    header('Location: ?page=login');
    exit;
}

// Handle login
if ($page === 'login') {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';
        
        if ($auth->login($email, $password)) {
            header('Location: ?page=dashboard');
            exit;
        } else {
            $error = 'Invalid credentials';
        }
    }
    
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Alpine Panel - Login</title>
        <link rel="stylesheet" href="assets/css/style.css">
    </head>
    <body class="login-page">
        <div class="login-box">
            <h1>Alpine Cloud Panel</h1>
            <form method="POST">
                <input type="email" name="email" placeholder="Email" required>
                <input type="password" name="password" placeholder="Password" required>
                <?php if (isset($error)): ?>
                    <p class="error"><?php echo htmlspecialchars($error); ?></p>
                <?php endif; ?>
                <button type="submit">Login</button>
            </form>
            <p class="hint">Demo: admin@alpine-panel.local / admin123</p>
        </div>
    </body>
    </html>
    <?php
    exit;
}

// Check auth
if (!$auth->isLoggedIn()) {
    header('Location: ?page=login');
    exit;
}

$stats = $system->getStats();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alpine Panel - <?php echo ucfirst($page); ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="sidebar">
        <h2>Alpine Panel</h2>
        <nav>
            <a href="?page=dashboard" class="<?php echo $page === 'dashboard' ? 'active' : ''; ?>">Dashboard</a>
            <a href="?page=servers" class="<?php echo $page === 'servers' ? 'active' : ''; ?>">Servers</a>
            <?php if ($auth->isAdmin()): ?>
                <a href="?page=admin" class="<?php echo $page === 'admin' ? 'active' : ''; ?>">Admin</a>
            <?php endif; ?>
            <a href="?logout=1">Logout</a>
        </nav>
    </div>

    <div class="main">
        <h1><?php echo ucfirst($page); ?></h1>

        <?php if ($page === 'dashboard'): ?>
            <div class="stats">
                <div class="stat-card">
                    <div class="label">CPU</div>
                    <div class="value"><?php echo $stats['cpu']; ?>%</div>
                </div>
                <div class="stat-card">
                    <div class="label">Memory</div>
                    <div class="value"><?php echo $stats['memory']['percent']; ?>%</div>
                </div>
                <div class="stat-card">
                    <div class="label">Disk</div>
                    <div class="value"><?php echo $stats['disk']['percent']; ?>%</div>
                </div>
                <div class="stat-card">
                    <div class="label">Uptime</div>
                    <div class="value"><?php echo $stats['uptime']; ?></div>
                </div>
            </div>

            <h2>Servers</h2>
            <div class="servers">
                <?php 
                $servers = $server->getServers();
                if (empty($servers)) {
                    echo '<p class="empty">No servers yet. <a href="?page=servers">Create one</a></p>';
                } else {
                    foreach ($servers as $srv) {
                        echo '<div class="server-card">';
                        echo '<h3>' . htmlspecialchars($srv['name']) . '</h3>';
                        echo '<p>Status: <strong>' . htmlspecialchars($srv['status']) . '</strong></p>';
                        echo '</div>';
                    }
                }
                ?>
            </div>

        <?php elseif ($page === 'servers'): ?>
            <button onclick="alert('Create server feature')">+ Create Server</button>
            <div class="servers">
                <?php 
                $servers = $server->getServers();
                foreach ($servers as $srv) {
                    echo '<div class="server-card">' . htmlspecialchars($srv['name']) . '</div>';
                }
                ?>
            </div>

        <?php elseif ($page === 'admin' && $auth->isAdmin()): ?>
            <p>Admin panel content</p>

        <?php else: ?>
            <p>Page not found</p>

        <?php endif; ?>
    </div>
</body>
</html>
