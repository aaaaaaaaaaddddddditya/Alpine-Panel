<?php
define('APP_NAME', 'Alpine Cloud Panel');
define('APP_VERSION', '1.0.0');
define('APP_DEBUG', getenv('DEBUG') === 'true');

// Roles
define('ROLE_OWNER', 'owner');
define('ROLE_ADMIN', 'admin');
define('ROLE_USER', 'user');

// Paths
define('STORAGE_PATH', dirname(__DIR__) . '/storage');
define('SERVERS_PATH', STORAGE_PATH . '/servers');
define('BACKUPS_PATH', STORAGE_PATH . '/backups');

// Settings
define('SESSION_TIMEOUT', 3600);
define('BCRYPT_ROUNDS', 10);
define('MAX_UPLOAD_SIZE', 104857600);
